مكتبات Bootstrap و jQuery مش مرفوعة هنا لتقليل حجم الملف.

قبل التشغيل، لازم تضيفي مكتبة Bootstrap و jQuery بإحدى الطريقتين:

الطريقة 1 (الأسهل - عبر LibMan، مدمج في VS Code/Visual Studio):
افتحي Terminal في مجلد المشروع واكتبي:

    dotnet tool install -g Microsoft.Web.LibraryManager.Cli
    libman install bootstrap@5.3.0 -d wwwroot/lib/bootstrap
    libman install jquery@3.7.0 -d wwwroot/lib/jquery

الطريقة 2 (يدوي):
نزلي bootstrap و jquery من موقعيهم الرسميين وحطيهم في:
    wwwroot/lib/bootstrap/dist/css/bootstrap.min.css
    wwwroot/lib/bootstrap/dist/js/bootstrap.bundle.min.js
    wwwroot/lib/jquery/dist/jquery.min.js

بعد كده الموقع هيشتغل بالتصميم كامل.
